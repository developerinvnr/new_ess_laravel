@include('employee.header');
@include('employee.sidebar');


<body class="mini-sidebar">
    <div class="loader" style="display: none;">
        <div class="spinner" style="display: none;">
            <img src="./SplashDash_files/loader.gif" alt="">
        </div>
    </div>
    <!-- Main Body -->
    <div class="page-wrapper">
        <!-- Header Start -->
        <header class="header-wrapper main-header">
            <div class="header-inner-wrapper">
                <div class="header-right">
                    <div class="serch-wrapper">
                        <form>
                            <input type="text" placeholder="Search Here...">
                        </form>
                        <a class="search-close" href="javascript:void(0);"><span class="icofont-close-line"></span></a>
                    </div>
                    <div class="header-left">
                        <div class="header-links d-none">
                            <a href="javascript:void(0);" class="toggle-btn">
                                <span></span>
                            </a>
                        </div>
                        <div class="header-links search-link">
                            <a class="search-toggle" href="javascript:void(0);">
                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg"
                                    xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                    viewBox="0 0 56.966 56.966" style="enable-background:new 0 0 56.966 56.966;"
                                    xml:space="preserve">
                                    <path d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23
                                    s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92
                                    c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17
                                    s-17-7.626-17-17S14.61,6,23.984,6z"></path>
                                </svg>
                            </a>
                        </div>
                        <div class="d-none d-md-block d-lg-block">
                            <h4>VNR Seeds Private Limited India</h4>
                        </div>
                    </div>
                    <div class="header-controls">
                        <div class="setting-wrapper header-links d-none">
                            <a href="javascript:void(0);" class="setting-info">
                                <span class="header-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path
                                            d="M18.777,12.289 L17.557,12.493 C17.439,12.854 17.287,13.220 17.105,13.585 L17.825,14.599 C18.236,15.178 18.170,15.964 17.668,16.467 L16.454,17.683 C15.960,18.177 15.139,18.238 14.588,17.838 L13.583,17.119 C13.234,17.294 12.869,17.446 12.491,17.571 L12.284,18.795 C12.167,19.497 11.566,20.006 10.855,20.006 L9.137,20.006 C8.426,20.006 7.825,19.497 7.708,18.794 L7.504,17.571 C7.138,17.450 6.786,17.305 6.455,17.139 L5.431,17.869 C4.875,18.268 4.060,18.202 3.570,17.712 L2.356,16.496 C1.853,15.995 1.787,15.209 2.200,14.627 L2.915,13.630 C2.735,13.279 2.581,12.913 2.456,12.540 L1.218,12.329 C0.518,12.212 0.009,11.609 0.009,10.898 L0.009,9.180 C0.009,8.468 0.518,7.865 1.219,7.748 L2.422,7.545 C2.545,7.164 2.694,6.797 2.867,6.447 L2.139,5.421 C1.727,4.842 1.793,4.057 2.295,3.553 L3.513,2.337 C3.991,1.846 4.818,1.777 5.380,2.181 L6.376,2.901 C6.725,2.721 7.091,2.566 7.464,2.441 L7.675,1.200 C7.793,0.498 8.394,-0.011 9.104,-0.011 L10.818,-0.011 C11.528,-0.011 12.130,0.498 12.247,1.201 L12.451,2.407 C12.833,2.530 13.214,2.687 13.591,2.877 L14.602,2.155 C15.157,1.757 15.973,1.822 16.463,2.313 L17.676,3.528 C18.180,4.028 18.246,4.814 17.833,5.396 L17.112,6.405 C17.288,6.754 17.440,7.121 17.564,7.500 L18.786,7.707 C19.492,7.825 19.997,8.429 19.986,9.143 L19.986,10.856 C19.986,11.569 19.478,12.172 18.777,12.289 ZM16.815,8.984 C16.507,8.935 16.256,8.705 16.180,8.397 C16.030,7.816 15.800,7.262 15.498,6.755 C15.339,6.480 15.353,6.140 15.536,5.887 L16.472,4.568 L15.421,3.514 L14.111,4.458 C13.855,4.640 13.515,4.654 13.248,4.495 C12.722,4.184 12.157,3.952 11.566,3.803 C11.261,3.727 11.030,3.475 10.977,3.162 L10.711,1.574 L9.227,1.574 L8.953,3.187 C8.902,3.490 8.675,3.739 8.375,3.822 C7.801,3.971 7.251,4.203 6.735,4.513 C6.463,4.675 6.124,4.660 5.866,4.481 L4.555,3.543 L3.503,4.595 L4.451,5.930 C4.632,6.183 4.648,6.521 4.491,6.790 C4.193,7.297 3.967,7.852 3.819,8.439 C3.744,8.743 3.494,8.975 3.181,9.028 L1.596,9.295 L1.596,10.782 L3.205,11.057 C3.508,11.108 3.758,11.336 3.839,11.636 C3.987,12.210 4.219,12.762 4.530,13.280 C4.690,13.552 4.676,13.893 4.496,14.150 L3.561,15.465 L4.612,16.518 L5.943,15.569 C6.170,15.399 6.533,15.375 6.799,15.528 C7.309,15.822 7.851,16.044 8.408,16.189 C8.708,16.265 8.937,16.514 8.990,16.825 L9.257,18.425 L10.740,18.425 L11.010,16.825 C11.057,16.516 11.287,16.265 11.594,16.189 C12.176,16.037 12.729,15.807 13.234,15.505 C13.509,15.344 13.850,15.360 14.101,15.542 L15.418,16.482 L16.469,15.428 L15.530,14.102 C15.348,13.843 15.334,13.512 15.494,13.239 C15.797,12.728 16.027,12.174 16.176,11.591 C16.253,11.289 16.503,11.060 16.811,11.007 L18.408,10.740 L18.413,9.255 L16.815,8.984 ZM10.000,14.453 C7.547,14.453 5.550,12.454 5.550,9.996 C5.550,7.537 7.547,5.537 10.000,5.537 C12.454,5.537 14.449,7.537 14.449,9.996 C14.449,12.454 12.454,14.453 10.000,14.453 ZM10.000,7.127 C8.422,7.127 7.137,8.413 7.137,9.996 C7.137,11.577 8.422,12.864 10.000,12.864 C11.579,12.864 12.863,11.577 12.863,9.996 C12.863,8.413 11.579,7.127 10.000,7.127 Z"
                                            class="cls-1"></path>
                                    </svg>
                                </span>
                            </a>
                        </div>

                        @include('employee.navbar');
                    </div>
                </div>
            </div>
        </header>
        <!-- Sidebar Start -->

        <!-- Container Start -->
        <div class="page-wrapper">
            <div class="main-content">
                <!-- Page Title Start -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-title-wrapper">
                            <div class="breadcrumb-list">
                                <ul>
                                    <li class="breadcrumb-link">
                                        <a href="index.html"><i class="fas fa-home mr-2"></i>Home</a>
                                    </li>
                                    <li class="breadcrumb-link active">Attendance/Leave</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Dashboard Start -->

                <div class="row">
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">
                        <!-- Start Card-->

                        <div class="card ad-info-card-">
                            <div class="card-body dd-flex align-items-center border-bottom-d">
                                <h5 class="mb-2 w-100"><b>Sick Leave(SL)</b></h5>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="pie-wrapper" style="margin: 0 auto;">
                                        <div style="border-color: #659093;" class="arc" data-value=""></div>
                                        <span class="score"> Day</span>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-2">
                                    <span class="float-start me-2">
                                        <span class="teken-leave">&nbsp;</span>
                                        {{ (isset($leaveBalance) && $leaveBalance->OpeningSL !== null && $leaveBalance->CreditedSL !== null)
    ? $leaveBalance->OpeningSL + $leaveBalance->CreditedSL
    : '0' }} Day
                                    </span>
                                    <span class="float-start me-2">
                                        <span class="upcoming-leave">&nbsp;</span>
                                        {{ isset($leaveBalance) && $leaveBalance->AvailedSL !== null
    ? $leaveBalance->AvailedSL
    : '0' }} Day
                                    </span>
                                    <span class="float-start">
                                        <span class="availabel-leave">&nbsp;</span>
                                        {{ isset($leaveBalance) && $leaveBalance->BalanceSL !== null
    ? $leaveBalance->BalanceSL
    : '0' }} Day
                                    </span>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- Start Card-->
                    @isset($leaveBalance)
                    <!-- Casual Leave -->
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">
                        <div class="card ad-info-card-">
                            <div class="card-body dd-flex align-items-center border-bottom-d">
                                <h5 class="mb-2 w-100"><b>Casual Leave (CL)</b></h5>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="pie-wrapper" style="margin: 0 auto;">
                                        <div style="border-color: #659093;" class="arc" data-value="">
                                            <span></span>
                                        </div>
                                        <div style="border-color: #f1d6d6; z-index: 1;" class="arc"
                                            data-value="{{ $leaveBalance->AvailedCL * 100 / max(($leaveBalance->OpeningCL + $leaveBalance->CreditedCL), 1) }}">
                                        </div>
                                        <span class="score">{{ $leaveBalance->AvailedCL ?? 0 }} Day</span>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-2">
                                    <span class="float-start me-2"><span class="teken-leave">&nbsp;</span>
                                        {{ ($leaveBalance->OpeningCL + $leaveBalance->CreditedCL) ?? 0 }} Day</span>
                                    <span class="float-start me-2"><span class="upcoming-leave">&nbsp;</span>
                                        {{ $leaveBalance->AvailedCL ?? 0 }} Day</span>
                                    <span class="float-start"><span class="availabel-leave">&nbsp;</span>
                                        {{ $leaveBalance->BalanceCL ?? 0 }} Day</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Privilege Leave -->
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">
                        <div class="card ad-info-card-">
                            <div class="card-body dd-flex align-items-center border-bottom-d">
                                <h5 class="mb-2 w-100"><b>Privilege Leave (PL)</b></h5>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="pie-wrapper" style="margin: 0 auto;">
                                        <div style="border-color: #659093;" class="arc" data-value=""></div>
                                        <div style="border-color: #f1d6d6; z-index: 1;" class="arc"
                                            data-value="{{ $leaveBalance->AvailedPL * 100 / max(($leaveBalance->OpeningPL + $leaveBalance->CreditedPL), 1) }}">
                                        </div>
                                        <span class="score">{{ $leaveBalance->AvailedPL ?? 0 }} Day</span>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-2">
                                    <span class="float-start me-2"><span class="teken-leave">&nbsp;</span>
                                        {{ ($leaveBalance->OpeningPL + $leaveBalance->CreditedPL) ?? 0 }} Day</span>
                                    <span class="float-start me-2"><span class="upcoming-leave">&nbsp;</span>
                                        {{ $leaveBalance->AvailedPL ?? 0 }} Day</span>
                                    <span class="float-start"><span class="availabel-leave">&nbsp;</span>
                                        {{ $leaveBalance->BalancePL ?? 0 }} Day</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Earned Leave -->
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">
                        <div class="card ad-info-card-">
                            <div class="card-body dd-flex align-items-center border-bottom-d">
                                <h5 class="mb-2 w-100"><b>Earned Leave (EL)</b></h5>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="pie-wrapper" style="margin: 0 auto;">
                                        <div style="border-color: #659093;" class="arc" data-value=""></div>
                                        <span class="score">{{ $leaveBalance->AvailedEL ?? 0 }} Day</span>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-2">
                                    <span class="float-start me-1"><span class="teken-leave">&nbsp;</span>
                                        {{ ($leaveBalance->OpeningEL + $leaveBalance->CreditedEL) ?? 0 }} Day</span>
                                    <span class="float-start me-1"><span class="upcoming-leave">&nbsp;</span>
                                        {{ $leaveBalance->AvailedEL ?? 0 }} Day</span>
                                    <span class="float-start"><span class="availabel-leave">&nbsp;</span>
                                        {{ $leaveBalance->BalanceEL ?? 0 }} Day</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Festival Leave -->
                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">
                        <div class="card ad-info-card-">
                            <div class="card-body dd-flex align-items-center border-bottom-d">
                                <h5 class="mb-2 w-100"><b>Festival Leave (FL)</b></h5>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="pie-wrapper" style="margin: 0 auto;">
                                        <div style="border-color: #659093;" class="arc" data-value=""></div>
                                        <span class="score">{{ $leaveBalance->AvailedOL ?? 0 }} Day</span>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-2">
                                    <span class="float-start me-2"><span class="teken-leave">&nbsp;</span>
                                        {{ ($leaveBalance->OpeningOL + $leaveBalance->CreditedOL) ?? 0 }} Day</span>
                                    <span class="float-start me-2"><span class="upcoming-leave">&nbsp;</span>
                                        {{ $leaveBalance->AvailedOL ?? 0 }} Day</span>
                                    <span class="float-start"><span class="availabel-leave">&nbsp;</span>
                                        {{ $leaveBalance->BalanceOL ?? 0 }} Day</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif

                    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">
                        <div class="card ad-info-card-">
                            <div class="card-body dd-flex align-items-center border-bottom-d">
                                <h5 class="mb-2 w-100"><b>Monthly Attendance</b></h5>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div style="border-color: #659093;margin:6px;" class="arc" data-value=""></div>
                                    <span class="me-4">Leave: <b>{{ $TotalLeaveCount ?? 0 }} Days</b>,</span><br>
                                    <span class="me-4">Holiday: <b>{{ $TotalHoliday ?? 0 }} Days</b>,</span><br>
                                    <span class="me-4">Outdoor Duties: <b>{{ $TotalOnDuties ?? 0 }} Days</b>,</span><br>
                                    <span class="me-4">Present: <b>{{ $TotalPR ?? 0 }} Days</b>,</span><br>
                                    <span class="me-4">Absent/ LWP: <b>{{ $TotalAbsent ?? 0 }} Days</b></span>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">
                        <div class="card ad-info-card-" style="height:143px;">
                            <div class="card-body dd-flex align-items-center border-bottom-d">
                                <h5 class="mb-2 w-100"><b>Monthly Attendance</b></h5>

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <p style="font-size:10px;">
                                            <span class="me-4">Leave: <b>{{ $TotalLeaveCount ?? 0 }} Days</b>,</span><br>
                                            <span class="me-4">Holiday: <b>{{ $TotalHoliday ?? 0 }} Days</b>,</span><br>
                                            <span class="me-4">Outdoor Duties: <b>{{ $TotalOnDuties ?? 0 }} Days</b>,</span><br>
                                            <span class="me-4">Present: <b>{{ $TotalPR ?? 0 }} Days</b>,</span><br>
                                            <span class="me-4">Absent/ LWP: <b>{{ $TotalAbsent ?? 0 }} Days</b></span><br>
                                    </p>

                                </div>

                            </div>
                        </div>
                    </div> -->



                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card ad-info-card-">
                            <div class="card-body">
                                <span class="leave-availabel float-start me-4"><span
                                        class="teken-leave">&nbsp;</span>Used Leave</span>
                                <span class="leave-availabel float-start me-4"><span
                                        class="upcoming-leave">&nbsp;</span>Plan Leave</span>
                                <span class="leave-availabel float-start"><span
                                        class="availabel-leave">&nbsp;</span>Balance Leave</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Revanue Status Start -->
                <div class="row">
                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12">

                        <div class="mfh-machine-profile">
                            <ul class="nav nav-tabs" id="myTab1" role="tablist"
                                style="background-color:#a5cccd;border-radius: 10px 10px 0px 0px;">
                                <li class="nav-item">
                                    <a style="color: #0e0e0e;" class="nav-link active" data-bs-toggle="tab"
                                        href="#LeaveStatistics" role="tab" aria-controls="LeaveStatistics"
                                        aria-selected="true">Attendance</a>
                                </li>
                                <li class="nav-item">
                                    <a style="color: #0e0e0e;" class="nav-link" data-bs-toggle="tab" href="#ApplyLeave"
                                        role="tab" aria-controls="ApplyLeave" aria-selected="false">Apply Leave</a>
                                </li>
                            </ul>
                            <div class="tab-content ad-content2" id="myTabContent2">
                                <div class="tab-pane fade active show" id="LeaveStatistics" role="tabpanel">
                                    <div class="card chart-card">
                                        <div class="card-header">
                                            <h4 class="has-btn float-start mt-2"></H4>
                                            <span class="float-end">
                                                <select class="select2 form-control select-opt" id="monthname"
                                                    fdprocessedid="7n33b9">
                                                    <option value="select">Select Month </option>
                                                    <!-- <option value="January">January</option>
															  <option value="February">February</option>
															  <option value="March">March</option>
															  <option value="April">April</option>
															  <option value="May">May</option>
															  <option value="June">June</option>
															  <option value="July">July</option>
															  <option value="August">August</option>
															  <option value="September">September</option> -->
                                                </select>
                                            </span>
                                        </div>
                                        <div class="card-body">
                                            <table class="calendar">
                                                <thead>
                                                    <tr class="weekday">
                                                        <th>Sunday</th>
                                                        <th>Monday</th>
                                                        <th>Tuesday</th>
                                                        <th>Wednesday</th>
                                                        <th>Thursday</th>
                                                        <th>Friday</th>
                                                        <th>Saturday</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>

                                                    </tr>

                                                </tbody>
                                            </table>
                                            <!-------------------------end----------------------->
                                        </div>
                                    </div>
                                    <!--<div class="card chart-card">
												<img class="w-100-" src="./images/Group 61.png">
											</div>
											<div class="card chart-card">
												<img class="w-100-" src="./images/Group 62.png">
											</div>
											<div class="card chart-card">
												<img class="w-100-" src="./images/Group 66.png">
											</div>
											<div class="card chart-card">
												<img class="w-100-" src="./images/Group 72.png">
											</div>
											<h5>Multi date leave</h5>
											<div class="card chart-card">
												<img class="w-100-" src="./images/Group 67.png">
											</div>
											<div class="card chart-card">
												<img class="w-100-" src="./images/Group 68.png">
											</div>
											<div class="card chart-card">
												<img class="w-100-" src="./images/Group 69.png">
											</div>
											<div class="card chart-card">
												<img class="w-100-" src="./images/Group 73.png">
											</div> -->
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="card ad-info-card-">
                                            <div class="card-body">
                                                <span class="leave-availabel float-start me-4"><span
                                                        class="repre-present">&nbsp;</span>Present(P)</span>
                                                <span class="leave-availabel float-start me-4"><span
                                                        class="repre-absent">&nbsp;</span>Absent(A)</span>
                                                <span class="leave-availabel float-start me-4">
                                                    <span class="repre-ch">&nbsp;</span>Half day CL(CH)</span>
                                                <span class="leave-availabel float-start me-4">
                                                    <span class="repre-sh">&nbsp;</span>Half day SL(SH)</span>
                                                <span class="leave-availabel float-start me-4">
                                                    <span class="repre-ph">&nbsp;</span>Half day PL(PH)</span>
                                                <span class="leave-availabel float-start me-4"><span
                                                        class="repre-ho">&nbsp;</span>Holiday(HO)</span>
                                                <span class="leave-availabel float-start me-4"><span
                                                        class="repre-od">&nbsp;</span>Outdoor Duties(OD)</span>
                                                <span class="leave-availabel float-start me-4"><span
                                                        class="repre-fl">&nbsp;</span>Festival Leaves(FL)</span>
                                                <span class="leave-availabel float-start me-4"><span
                                                        class="repre-tl">&nbsp;</span>Transfer Leave(TL)</span>
                                                <span class="leave-availabel float-start me-4"><span
                                                        class="repre-wfh">&nbsp;</span>Work from home(WFH)</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="ApplyLeave" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="alert alert-danger" id="leaveMessage" style="display: none;">
                                            </div>

                                            <form id="leaveForm" action="{{ route('leaveform') }}" method="POST">
                                                @csrf
                                                <input type="hidden" name="employee_id"
                                                    value="{{ Auth::user()->EmployeeID }}">

                                                <div class="row">
                                                    <!-- General From Date -->
                                                    <div class="col-xl-4">
                                                        <div class="form-group s-opt">
                                                            <label for="fromDate" class="col-form-label">From
                                                                Date</label>
                                                            <input class="form-control" type="date" id="fromDate"
                                                                name="fromDate" required min="{{ date('Y-m-d') }}"
                                                                value="{{ date('Y-m-d') }}">
                                                        </div>
                                                    </div>

                                                    <!-- General To Date -->
                                                    <div class="col-xl-4">
                                                        <div class="form-group s-opt">
                                                            <label for="toDate" class="col-form-label">To Date</label>
                                                            <input class="form-control" type="date" id="toDate"
                                                                name="toDate" required min="{{ date('Y-m-d') }}"
                                                                value="{{ date('Y-m-d') }}">
                                                        </div>
                                                    </div>

                                                    <!-- New HTML Structure for SL -->
                                                    <!-- <div class="col-xl-4" id="slDateSectionFrom" style="display:none;">
                                                        <div class="form-group s-opt">
                                                            <label for="fromDateSL" class="col-form-label">From Date
                                                                (SL)</label>
                                                            <input class="form-control" type="date" id="fromDateSL"
                                                                name="fromDateSL" required>
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-4" id="slDateSectionTo" style="display:none;">
                                                        <div class="form-group s-opt">
                                                            <label for="toDateSL" class="col-form-label">To Date
                                                                (SL)</label>
                                                            <input class="form-control" type="date" id="toDateSL"
                                                                name="toDateSL" required>
                                                        </div>
                                                    </div> -->

                                                    <!-- Leave Type -->
                                                    <div class="col-xl-4">
                                                        <div class="form-group s-opt">
                                                            <label for="leaveType" class="col-form-label">Leave
                                                                Type</label>
                                                            <select class="select2 form-control select-opt"
                                                                id="leaveType" name="leaveType" required>
                                                                <option value="" disabled selected>Select Leave Type
                                                                </option> <!-- Default option -->

                                                                @isset ($leaveBalance)
                                                                    @if ($leaveBalance->BalanceCL > 0)
                                                                        <option value="CL">Casual Leave (Available:
                                                                            {{ $leaveBalance->BalanceCL }})
                                                                        </option>
                                                                    @endif
                                                                    @if ($leaveBalance->BalanceSL > 0)
                                                                        <option value="SL">Sick Leave (Available:
                                                                            {{ $leaveBalance->BalanceSL }})
                                                                        </option>
                                                                    @endif
                                                                    @if ($leaveBalance->BalancePL > 0)
                                                                        <option value="PL">Privilege Leave (Available:
                                                                            {{ $leaveBalance->BalancePL }})
                                                                        </option>
                                                                    @endif
                                                                    @if ($leaveBalance->BalanceEL > 0)
                                                                        <option value="EL">Earned Leave (Available:
                                                                            {{ $leaveBalance->BalanceEL }})
                                                                        </option>
                                                                    @endif
                                                                    @if ($leaveBalance->BalanceOL > 0)
                                                                        <option value="OL">Festival Leave(Available:
                                                                            {{ $leaveBalance->BalanceOL }})
                                                                        </option>
                                                                    @endif
                                                                @else
                                                                <option value="">No leave types available</option>
                                                                @endif
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <!-- Optional Holidays Dropdown -->
                                                    <div class="col-xl-4" id="holidayDropdown" style="display: none;">
                                                        <div class="form-group s-opt">
                                                            <label for="optionalHoliday" class="col-form-label">Select
                                                                Holiday</label>
                                                            <select class="select2 form-control select-opt"
                                                                id="optionalHoliday" name="optionalHoliday">
                                                                <option value="" disabled selected>Select Holiday
                                                                </option> <!-- Default option -->

                                                                @if(isset($optionalHolidays) && $optionalHolidays->isNotEmpty())
                                                                    @foreach ($optionalHolidays as $holiday)
                                                                        <option value="{{ $holiday->HoOpDate }}">
                                                                            {{ $holiday->HoOpName }}
                                                                        </option>
                                                                    @endforeach
                                                                @else
                                                                    <option value="">No optional holidays available</option>
                                                                @endif
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <!-- Option -->
                                                    <div class="col-xl-4">
                                                        <div class="form-group s-opt">
                                                            <label for="option" class="col-form-label">Option</label>
                                                            <select class="select2 form-control select-opt" id="option"
                                                                name="option" required>
                                                                <option value="fullday">Full Day</option>
                                                                <option value="1sthalf">1st Half</option>
                                                                <option value="2ndhalf">2nd Half</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <!-- Contact No -->
                                                    <div class="col-xl-4">
                                                        <div class="form-group s-opt">
                                                            <label for="contactNo" class="col-form-label">Contact
                                                                No.</label>
                                                            <input class="form-control" type="text" id="contactNo"
                                                                name="contactNo" placeholder="Enter contact number"
                                                                required>
                                                        </div>
                                                    </div>
                                                    <!-- Address -->
                                                    <div class="col-xl-4">
                                                        <div class="form-group s-opt">
                                                            <label for="address" class="col-form-label">Address</label>
                                                            <input class="form-control" type="text" id="address"
                                                                name="address" placeholder="Enter address" required>
                                                        </div>
                                                    </div>
                                                    <!-- Reason for Leave -->
                                                    <div class="form-group">
                                                        <label for="reason" class="col-form-label">Reason for
                                                            Leave</label>
                                                        <textarea class="form-control" id="reason" name="reason"
                                                            placeholder="Enter reason" required></textarea>
                                                    </div>
                                                    <!-- Submit Button -->
                                                    <div class="form-group mb-0">
                                                        <button class="btn btn-primary" type="submit">Submit</button>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">

                                                    <div class="card-header mb-4 mt-4">
                                                        <h4 class="has-btn">Leave List</h4>
                                                    </div>
                                                    <table class="table table-styled mb-0">
                                                        <thead>
                                                            <tr>
                                                                <th>S.No.</th>
                                                                <th>Apply Date</th>
                                                                <th>From Date</th>
                                                                <th>To Date</th>
                                                                <th>Total</th>
                                                                <th>Leave Type</th>
                                                                <th>Reporting Reason</th>

                                                                <th>Leave Reason</th>
                                                                <th>Status</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            @foreach(Auth::user()->employeeleave as $index => $leave)

                                                                <tr class="leave-row">
                                                                    <td>{{ $index + 1 }}.</td>
                                                                    <td style="width:80px;">{{ $leave->Apply_Date }}</td>
                                                                    <td style="width:80px;">{{ $leave->Apply_FromDate }}
                                                                    </td>
                                                                    <td style="width:80px;">{{ $leave->Apply_ToDate }}</td>
                                                                    <td style="width:70px;">{{ $leave->Apply_TotalDay }}
                                                                        {{ $leave->Apply_TotalDay == 1 ? 'Day' : 'Days' }}
                                                                    </td>
                                                                    <td style="width:80px;">
                                                                        <label class="mb-0 badge badge-secondary" title=""
                                                                            data-original-title="{{ $leave->Leave_Type }}">{{ $leave->Leave_Type }}</label>
                                                                    </td>
                                                                    <td>
                                                                        <p>{{ $leave->LeaveRevReason }}</p>
                                                                    </td>
                                                                    <td>
                                                                        <p>{{ $leave->Apply_Reason }}</p>
                                                                    </td>
                                                                    <td style="text-align:right;">
                                                                        @if ($leave->LeaveStatus == 0)
                                                                            <label style="padding:6px 13px;font-size: 11px;"
                                                                                class="mb-0 sm-btn btn-outline danger-outline"
                                                                                title=""
                                                                                data-original-title="Draft">Reject/Draft</label>
                                                                        @elseif ($leave->LeaveStatus == 1)
                                                                            <label style="padding:6px 13px;font-size: 11px;"
                                                                                class="mb-0 sm-btn btn-outline success-outline"
                                                                                title=""
                                                                                data-original-title="Pending">Approved</label>
                                                                        @elseif ($leave->LeaveStatus == 2)
                                                                            <label style="padding:6px 13px;font-size: 11px;"
                                                                                class="mb-0 sm-btn btn-outline success-outline"
                                                                                title=""
                                                                                data-original-title="Approved">Approved</label>
                                                                        @elseif ($leave->LeaveStatus == 3)
                                                                            <label style="padding:6px 13px;font-size: 11px;"
                                                                                class="mb-0 sm-btn btn-outline danger-outline"
                                                                                title=""
                                                                                data-original-title="Disapproved">Disapproved</label>
                                                                        @endif
                                                                    </td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>

                                                    <div class="text-right pt-2">
                                                        <nav>
                                                            <ul class="pagination" id="pagination"></ul>
                                                        </nav>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                        <div class="card chart-card">
                            <div class="card-header">
                                <h4 class="has-btn"></h4>
                            </div>
                            <div class="card-body">
                                <div class="late-atnd">

                                </div>

                            </div>
                        </div>
                        <!-- <div class="card chart-card" id="list_of_attendance_req">
                            <div class="card-header" id="list_of_attendance_req_card">
                                <h4 class="has-btn"></h4>
                            </div>

                            <div class="card-body" id="list_of_attendance_req_body">
                                @foreach (Auth::user()->employeeAttendanceRequest as $attendance)
                                    <div class="list_of_attendance_req_content">
                                        <h6 class="float-start mt-2">{{ $attendance->AttDate }}</h6>

                                        <div class="float-end mt-1">
                                            <label style="padding:6px 13px;font-size: 11px;"
                                                class="mb-0 sm-btn btn-outline success-outline" title="Approval">
                                                {{ $attendance->Status == 1 ? 'Approved' : 'Rejected' }}
                                            </label>
                                        </div>
                                    </div>

                                    <div class="list_of_attendance_req_content">
                                        <div class="row">
                                            @if($attendance->InReason && $attendance->InRemark)
                                                <div class="col-md-6">
                                                    <p><strong>In Reason: </strong>{{ $attendance->InReason }}</p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p><strong>In Remark: </strong>{{ $attendance->InRemark }}</p>
                                                </div>
                                            @elseif($attendance->OutReason && $attendance->OutRemark)
                                                <div class="col-md-6">
                                                    <p><strong>Out Reason: </strong>{{ $attendance->OutReason }}</p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p><strong>Out Remark: </strong>{{ $attendance->OutRemark }}</p>
                                                </div>
                                            @elseif($attendance->Reason && $attendance->Remark)
                                                <div class="col-md-6">
                                                    <p><strong>Reason: </strong>{{ $attendance->Reason }}</p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p><strong>Remark: </strong>{{ $attendance->Remark }}</p>
                                                </div>
                                            @else
                                                <div class="col-md-12">
                                                    <p><strong>No Reason or Remark provided.</strong></p>
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="list_of_attendance_req_content">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p><strong>Request Date: </strong>{{ $attendance->ReqDate }}</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="list_of_attendance_req_content">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p><strong>Created Date: </strong>{{ $attendance->CrDate }}</p>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>



                        </div> -->



                        <div class="card chart-card">
                            <ul class="nav nav-tabs" id="myTab1" role="tablist">
                                <li class="nav-item">
                                    <a style="color: #0e0e0e;" class="nav-link active" data-bs-toggle="tab"
                                        href="#MonthHoliday" role="tab" aria-controls="MonthHoliday"
                                        aria-selected="true">Holiday</a>
                                </li>
                                <li class="nav-item">
                                    <a style="color: #0e0e0e;" class="nav-link" data-bs-toggle="tab"
                                        href="#FestivalLeave" role="tab" aria-controls="FestivalLeave"
                                        aria-selected="false">Festival Leave(Optional)</a>
                                </li>
                            </ul>
                            <div class="tab-content ad-content2" id="myTabContent2">
                                <div class="tab-pane fade active show" id="MonthHoliday" role="tabpanel">
                                    <div class="card-body" style="height:450px;overflow-y:auto;">
                                        @if(empty($holidays))
                                            <p>No holidays available.</p>
                                        @else
                                            @foreach ($holidays as $holiday)

                                                <!-- <h6 class="mb-2">
                                                                                                    {{ \Carbon\Carbon::parse($holiday->HolidayDate)->format('d M') }}</h6>
                                                                                                <div class="holiday-entry">
                                                                                                    <label class="mb-0">{{ $holiday->HolidayName }}</label><br>
                                                                                                    <span class="float-start">{{ $holiday->Day }}</span>
                                                                                                    <span class="float-end">
                                                                                                        <label
                                                                                                            class="mb-0 badge badge-success toltiped">{{ \Carbon\Carbon::parse($holiday->HolidayDate)->format('d M') }}</label>
                                                                                                    </span> 
                                                                                                </div> -->

                                                <div class="holiday-entry d-flex align-items-center">
                                                    <h6 class="mb-0 me-2">
                                                        <strong
                                                            class="text-bold">{{ \Carbon\Carbon::parse($holiday->HolidayDate)->format('d M') }}</strong>
                                                    </h6>
                                                    <label class="mb-0 me-2"><strong
                                                            class="text-bold">{{ $holiday->HolidayName }}</strong></label>
                                                    <span class="float-start"><strong
                                                            class="text-bold">{{ $holiday->Day }}</strong></span>
                                                </div>
                                                @if(!empty($holiday->fes_image_path))
                                                    <img class="mb-2"
                                                        src="{{ asset('images/holiday_fes_image/' . $holiday->fes_image_path) }}"
                                                        alt="{{ $holiday->HolidayName }}" /><br>
                                                @endif
                                            @endforeach
                                        @endif
                                        <a class="btn-outline secondary-outline mr-2 sm-btn mt-2" href=""
                                            data-bs-toggle="modal" data-bs-target="#model3">All Holiday List</a>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="FestivalLeave" role="tabpanel">
                                    <div class="card-body" style="height:450px;overflow-y:auto;">
                                        @if(isset($optionalHolidays) && empty($optionalHolidays))
                                            <p>No optional holidays available for this year.</p>
                                        @elseif(isset($optionalHolidays))
                                            @foreach($optionalHolidays as $optionalHoliday)
                                                <div class="fest-leave">
                                                    <label class="mb-0">{{ $optionalHoliday->HoOpName }}</label><br>
                                                    <span
                                                        class="float-start">{{ \Carbon\Carbon::parse($optionalHoliday->HoOpDate)->format('l') }}</span>
                                                    <span class="float-end">
                                                        <label
                                                            class="mb-0 badge badge-success toltiped">{{ \Carbon\Carbon::parse($optionalHoliday->HoOpDate)->format('d M') }}</label>
                                                    </span>
                                                </div>
                                            @endforeach
                                        @else
                                            <p>Optional holidays data not found.</p>
                                        @endif

                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="card chart-card d-none">
                            <div class="card-header">
                                <h4 class="has-btn">Leave Suggestion</h4>
                            </div>
                            <div class="card-body">
                                <h6 class="mb-2">August - 2 Days </h6>
                                <table class="table table-styled mb-0">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-success toltiped">15 August</label>
                                            </td>
                                            <td>
                                                <label class="mb-0 ">Independence Day Holiday</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-info toltiped">16 August</label>
                                            </td>
                                            <td>
                                                <label class="mb-0">PL</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-info toltiped">17 August</label>
                                            </td>
                                            <td>
                                                <label class="mb-0">PL</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-success toltiped">18 August</label>
                                            </td>
                                            <td>
                                                <label class="mb-0">Sunday</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-success toltiped">19 August</label>
                                            </td>
                                            <td>
                                                <label class="mb-0">Raksha Bandhan Holiday</label>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <p>Do you want apply this leave</p>
                                <a class="btn-outline secondary-outline mr-2 sm-btn mt-2 float-end" href="">Yes</a>
                                <br>
                                <hr>
                                <br>
                                <h6 class="mb-2">Ocotober - 3 Days </h6>
                                <table class="table table-styled mb-0">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-success toltiped">2 Ocotober</label>
                                            </td>
                                            <td>
                                                <label class="mb-0">Gandhi jayanti Holiday</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-info toltiped">3 October</label>
                                            </td>
                                            <td>
                                                <label class="mb-0">EL</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-info toltiped">4 Ocotober</label>
                                            </td>
                                            <td>
                                                <label class="mb-0">EL</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-info toltiped">5 Ocotober</label>
                                            </td>
                                            <td>
                                                <label class="mb-0">EL</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="mb-0 badge badge-success toltiped">6 Ocotober</label>
                                            </td>
                                            <td>
                                                <label class="mb-0">Sunday</label>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                                <p>Do you want apply this leave</p>
                                <a class="btn-outline secondary-outline mr-2 sm-btn mt-2 float-end" href="">Yes</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 d-none">
                        <h5 class="mt-2 mb-4">Leave Request Status</h5>
                        <div class="row">
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                                <div class="card chart-card">
                                    <div class="card-body">
                                        <h5 class="text-center p-3 mb-3" style="background-color: #f1f1f1;">Pending</h5>
                                        <span><b>Sick Leave</b></span>
                                        <span class="float-end apply-date">Apply Date: 12-01-2023</span><br>
                                        <div class="mt-5 mb-4 text-center">
                                            <div class="float-start"><b>Jan</b>&nbsp;&nbsp;<b
                                                    class="singal-date">14</b>&nbsp;&nbsp;<b>Mon</b></div>
                                            <span style="color: #ff3c41;"><b>1 Days</b></span>
                                            <div class="float-end"><b>Jan</b>&nbsp;&nbsp;<b
                                                    class="singal-date">14</b>&nbsp;&nbsp;<b>Mon</b></div>
                                        </div>
                                        <div class="progress mt-5 mb-2">
                                            <div class="progress-bar bg-secondary col-5" role="progressbar"
                                                aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <p class="text-center">8 Sick Leave Available</p>
                                        <div class="">
                                            <h6 class="mt-3 mb-2">Reason</h6>
                                            <p class="border p-3">I have to attend to a medical emergency of a close
                                                relative. I will have to be away from 2 days. i will resume work from.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                                <div class="card chart-card">
                                    <div class="card-body">
                                        <h5 class="text-center p-3 mb-3" style="background-color: #c4e9cd;">Approval
                                        </h5>
                                        <span><b>Privilege Leave</b></span>
                                        <span class="float-end apply-date">Apply Date: 12-01-2023</span><br>

                                        <div class="mt-5 mb-4 text-center">
                                            <div class="float-start"><b>Jan</b>&nbsp;&nbsp;<b
                                                    class="singal-date">24</b>&nbsp;&nbsp;<b>Mon</b></div>
                                            <span style="color: #ff3c41;"><b>2 Days</b></span>
                                            <div class="float-end"><b>Jan</b>&nbsp;&nbsp;<b
                                                    class="singal-date">25</b>&nbsp;&nbsp;<b>Thus</b></div>
                                        </div>

                                        <div class="progress mt-5 mb-2">
                                            <div class="progress-bar bg-secondary col-5" role="progressbar"
                                                aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <p class="text-center">4 Privilege Leave Available</p>
                                        <div class="">
                                            <h6 class="mt-3 mb-2">Reason</h6>
                                            <p class="border p-3">I have to attend to a medical emergency of a close
                                                relative. I will have to be away from 2 days. i will resume work from.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                                <div class="card chart-card">
                                    <div class="card-body">
                                        <h5 class="text-center p-3 mb-3" style="background-color: #c5e1e9;">Request</h5>
                                        <span><b>Casual Leave</b></span>
                                        <span class="float-end apply-date">Apply Date: 12-01-2023</span><br>

                                        <div class="mt-5 mb-4 text-center">
                                            <div class="float-start"><b>Jan</b>&nbsp;&nbsp;<b
                                                    class="singal-date">08</b>&nbsp;&nbsp;<b>Mon</b></div>
                                            <span style="color: #ff3c41;"><b>3 Days</b></span>
                                            <div class="float-end"><b>Jan</b>&nbsp;&nbsp;<b
                                                    class="singal-date">10</b>&nbsp;&nbsp;<b>Wed</b></div>
                                        </div>

                                        <div class="progress mt-5 mb-2">
                                            <div class="progress-bar bg-secondary col-5" role="progressbar"
                                                aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <p class="text-center">8 Casual Leave Available</p>
                                        <div class="">
                                            <h6 class="mt-3 mb-2">Reason</h6>
                                            <p class="border p-3">I have to attend to a medical emergency of a close
                                                relative. I will have to be away from 2 days. i will resume work from.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ad-footer-btm">
                    <p><a href="">Tarms of use </a> | <a href="">Privacy Policy</a> Copyright 2023 © VNR Seeds Pvt. Ltd
                        India All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
    <!--Holiday list modal-->
    <div class="modal fade show" id="model3" tabindex="-1" aria-labelledby="exampleModalCenterTitle"
        style="display: none;" aria-modal="true" role="dialog">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle3">
                        {{ isset($currentYear) ? $currentYear : 'Current Year' }} - Holiday List
                    </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table table-styled mb-0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Holiday Name</th>
                                <th>Date</th>
                                <th>Day</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($all_holidays) && $all_holidays->isEmpty())
                                <tr>
                                    <td colspan="4" class="text-center">No holidays available for this year.</td>
                                </tr>
                            @elseif(isset($all_holidays))
                                @foreach($all_holidays as $index => $holiday)
                                    <tr>
                                        <td>{{ $index + 1 }}.</td>
                                        <td>
                                            @if(!empty($holiday->fes_image_path))
                                                <img style="width: 110px;"
                                                    src="{{ asset('images/holiday_fes_image/' . $holiday->fes_image_path) }}"
                                                    alt="{{ $holiday->HolidayName }}" />
                                            @endif
                                            <span class="img-thumb">
                                                <span class="ml-2">{{ $holiday->HolidayName }}</span>
                                            </span>
                                        </td>
                                        <td>{{ \Carbon\Carbon::parse($holiday->HolidayDate)->format('d/m/Y') }}</td>
                                        <td>{{ \Carbon\Carbon::parse($holiday->HolidayDate)->format('l') }}</td>
                                    </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="4" class="text-center">Holidays data not found.</td>
                                </tr>
                            @endif
                        </tbody>


                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-outline secondary-outline mt-2 mr-2 sm-btn"
                        data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


    <!--Attendence Authorisation-->
    <div class="modal fade" id="AttendenceAuthorisation" tabindex="-1" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Attendance Authorization</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="responseMessage" class="text-success" style="display: none;"></p>

                    <p>This option is only for missed attendance or late In-time/early out-time attendance and not for
                        leave applications. <span class="text-danger">Do not apply leave here.</span></p>
                    <br>
                    <p><b> </b><span id="request-date"></span></p>
                    <form id="attendanceForm" method="POST" action="{{ route('attendance.authorize') }}">
                        @csrf
                        <div id="request-date"></div>
                        <input type="hidden" id="employeeid" name="employeeid">
                        <input type="hidden" id="Atct" name="Atct">
                        <input type="hidden" id="requestDate" name="requestDate">

                        <div class="form-group" id="reasonInGroup" style="display: none;">
                            <label class="col-form-label">Reason In:</label>
                            <select name="reasonIn" class="form-control" id="reasonInDropdown">
                                <option value="">Select Reason</option>

                            </select>
                        </div>

                        <div class="form-group" id="remarkInGroup" style="display: none;">
                            <label class="col-form-label">Remark In:</label>
                            <input type="text" name="remarkIn" class="form-control" id="remarkIn"
                                placeholder="Remark In">
                        </div>

                        <div class="form-group" id="reasonOutGroup" style="display: none;">
                            <label class="col-form-label">Reason Out:</label>
                            <select name="reasonOut" class="form-control" id="reasonOutDropdown">
                                <option value="">Select Reason</option>

                            </select>
                        </div>

                        <div class="form-group" id="remarkOutGroup" style="display: none;">
                            <label class="col-form-label">Remark Out:</label>
                            <input type="text" name="remarkOut" class="form-control" id="remarkOut"
                                placeholder="remark out">
                        </div>
                        <div class="form-group" id="otherReasonGroup" style="display: none;">
                            <label class="col-form-label">Other Reason:</label>
                            <select name="otherReason" class="form-control" id="otherReasonDropdown">
                                <option value="">Select Reason</option>
                                <!-- Options will be populated dynamically -->
                            </select>
                        </div>


                        <div class="form-group" id="otherRemarkGroup" style="display: none;">
                            <label class="col-form-label">Other Remark:</label>
                            <input type="text" name="otherRemark" class="form-control" id="otherRemark"
                                placeholder="other remark">
                        </div>
                        <div class="form-group" id="OtherRemarkDataGroup" style="display: none;">
                            <label class="col-form-label">Other Remark:</label>
                            <input type="text" name="OtherRemarkData" class="form-control" id="OtherRemarkData"
                                placeholder="Enter reporting remark" readonly>
                        </div>
                        <div class="form-group" id="OtherReasonDataGroup" style="display: none;">
                            <label class="col-form-label">Other Reason:</label>
                            <input type="text" name="OtherReasonData" class="form-control" id="OtherReasonData"
                                placeholder="Enter reporting remark" readonly>
                        </div>
                        <div class="form-group" id="reportingRemarkGroup" style="display: none;">
                            <label class="col-form-label">Reporting Remark:</label>
                            <input type="text" name="reportingRemark" class="form-control" id="reportingRemark"
                                placeholder="Enter reporting remark" readonly>
                        </div>


                    </form>
                </div>
                <div class="modal-footer" id="modal-footer">
                    <button type="button" class="btn-outline secondary-outline mt-2 mr-2 sm-btn"
                        data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="sendButton">Send</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Preview Setting Box -->
    <div class="slide-setting-box">
        <div class="slide-setting-holder">
            <div class="setting-box-head">
                <h4>Dashboard Demo</h4>
                <a href="javascript:void(0);" class="close-btn">Close</a>
            </div>
            <div class="setting-box-body">
                <div class="sd-light-vs">
                    <a href="">
                        Light Version
                        <img src="./SplashDash_files/light.png" alt="">
                    </a>
                </div>
                <div class="sd-light-vs">
                    <a href="">
                        dark Version
                        <img src="./SplashDash_files/dark.png" alt="">
                    </a>
                </div>
            </div>
            <div class="sd-color-op">
                <h5>color option</h5>
                <div id="style-switcher">
                    <div>
                        <ul class="colors">
                            <li>
                                <p class="colorchange" id="color">
                                </p>
                            </li>
                            <li>
                                <p class="colorchange" id="color2">
                                </p>
                            </li>
                            <li>
                                <p class="colorchange" id="color3">
                                </p>
                            </li>
                            <li>
                                <p class="colorchange" id="color4">
                                </p>
                            </li>
                            <li>
                                <p class="colorchange" id="color5">
                                </p>
                            </li>
                            <li>
                                <p class="colorchange" id="style">
                                </p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Preview Setting -->

    @include('employee.footer');
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const currentDate = new Date();
            const currentMonthIndex = currentDate.getMonth(); // 0 = January, 1 = February, etc.
            const currentYear = currentDate.getFullYear();

            const monthNames = [
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'
            ];

            const monthDropdown = document.getElementById('monthname');
            const cardHeaders = document.querySelectorAll('.card-header h4');
            const list_of_attendance_req_card = document.querySelector('#list_of_attendance_req_card h4');

            monthDropdown.innerHTML = `<option value="select">Select Month</option>`;

            // Populate the dropdown with all months
            for (let i = currentMonthIndex; i >= 0; i--) {
                const month = monthNames[i];
                monthDropdown.innerHTML += `<option value="${month}">${month}</option>`;
            }
            // Optionally select the current month
            // monthDropdown.value = monthNames[currentMonthIndex];

            // Add the previous month option
            const previousMonthIndex = (currentMonthIndex - 1 + 12) % 12;
            const previousMonth = monthNames[previousMonthIndex];
            // monthDropdown.innerHTML += `<option value="${previousMonth}">${previousMonth}</option>`;

            // Fetch attendance data for the current month on page load
            fetchAttendanceData(monthNames[currentMonthIndex], currentYear);
            const rowsPerPage = 5; // Number of records per page
            const rows = document.querySelectorAll('.leave-row'); // Get all leave rows
            const pagination = document.getElementById('pagination');
            const totalPages = Math.ceil(rows.length / rowsPerPage);

            function showPage(page) {
                // Hide all rows
                rows.forEach((row, index) => {
                    row.style.display = (Math.floor(index / rowsPerPage) === page) ? '' : 'none';
                });
            }

            function createPagination() {

                for (let i = 0; i < totalPages; i++) {
                    const li = document.createElement('li');

                    li.className = 'page-item';
                    li.innerHTML = `<a class="page-link" href="#">${i + 1}</a>`;

                    li.addEventListener('click', function () {
                        showPage(i);
                    });
                    pagination.appendChild(li);
                }
            }

            createPagination();
            showPage(0);

            const leaveTypeSelect = document.getElementById('leaveType');
            const holidayDropdown = document.getElementById('holidayDropdown');
            const optionSelect = document.getElementById('option');
            const fromDateInput = document.getElementById('fromDate');
            const toDateInput = document.getElementById('toDate');
            const slDateSectionFrom = document.getElementById('slDateSectionFrom');
            const slDateSectionTo = document.getElementById('slDateSectionTo');
            const fromDateSLInput = document.getElementById('fromDateSL');
            const toDateSLInput = document.getElementById('toDateSL');

            // Leave balances
            const balanceCL = {{ isset($leaveBalance) ? $leaveBalance->BalanceCL : 0 }}; // Casual Leave balance
            const balanceSL = {{ isset($leaveBalance) ? $leaveBalance->BalanceSL : 0 }}; // Sick Leave balance

            leaveTypeSelect.addEventListener('change', function () {
                console.log(this.value);

                // Reset the option selection
                optionSelect.selectedIndex = 0; // Reset to the first option
                holidayDropdown.style.display = 'none'; // Hide holiday dropdown by default
                optionSelect.querySelectorAll('option').forEach(option => {
                    option.style.display = 'block'; // Reset to show all options
                });

                // Show general date fields
                fromDateInput.parentElement.parentElement.style.display = 'block'; // Show general From Date
                toDateInput.parentElement.parentElement.style.display = 'block'; // Show general To Date



                if (this.value === 'OL') {
                    holidayDropdown.style.display = 'block';
                    optionSelect.value = 'fullday'; // Auto-select Full Day
                    optionSelect.querySelectorAll('option').forEach(option => {
                        option.style.display = (option.value === 'fullday') ? 'block' : 'none'; // Hide others
                    });

                } else if (this.value === 'EL' || this.value === 'PL') {
                    holidayDropdown.style.display = 'none';
                    optionSelect.value = 'fullday'; // Auto-select Full Day
                    optionSelect.querySelectorAll('option').forEach(option => {
                        option.style.display = (option.value === 'fullday') ? 'block' : 'none'; // Hide others
                    });
                    setDateLimits();
                } else if (this.value === 'CL') {
                    holidayDropdown.style.display = 'none';
                    optionSelect.value = 'fullday'; // Auto-select Full Day

                    // Determine which options to show based on leave balance
                    if (balanceCL >= 1) {
                        optionSelect.querySelectorAll('option').forEach(option => {
                            option.style.display = 'block'; // Show all options
                        });
                    } else {
                        optionSelect.querySelectorAll('option').forEach(option => {
                            if (option.value === '1sthalf' || option.value === '2ndhalf') {
                                option.style.display = 'block'; // Show half-day options
                            } else {
                                option.style.display = 'none'; // Hide full day option
                            }
                        });
                    }
                    setDateLimits();
                } else if (this.value === 'SL') {
                    fromDateInput.parentElement.parentElement.style.display = 'block'; // Show general From Date
                    toDateInput.parentElement.parentElement.style.display = 'block'; // Show general To Date

                    // Determine options based on Sick Leave balance
                    if (balanceSL >= 1) {
                        optionSelect.querySelectorAll('option').forEach(option => {
                            option.style.display = 'block'; // Show all options
                        });
                    } else {
                        optionSelect.querySelectorAll('option').forEach(option => {
                            if (option.value === '1sthalf' || option.value === '2ndhalf') {
                                option.style.display = 'block'; // Show half-day options
                            } else {
                                option.style.display = 'none'; // Hide full day option
                            }
                        });
                    }
                    setDateLimits();
                }

                function setDateLimits() {
                    // Reset date inputs min and max when changing leave type
                    const currentDate = new Date();
                    const threeDaysAgo = new Date(currentDate);
                    threeDaysAgo.setDate(currentDate.getDate() - 3);
                    const minDate = threeDaysAgo.toISOString().split('T')[0]; // Three days ago

                    // Set min dates for the general inputs
                    fromDateInput.min = minDate; // Allow dates from 3 days ago
                    toDateInput.min = minDate; // Allow dates from 3 days ago

                    // Clear max to allow selection of any past date
                    fromDateInput.max = ""; // No maximum limit
                    toDateInput.max = ""; // No maximum limit

                    // Default to today's date
                    fromDateInput.value = currentDate.toISOString().split('T')[0]; // Default From Date to today
                    toDateInput.value = currentDate.toISOString().split('T')[0]; // Default To Date to today
                }
            });

            // Automatically set from and to dates when a holiday is selected
            document.getElementById('optionalHoliday').addEventListener('change', function () {
                const selectedHolidayDate = this.value; // Get selected holiday date
                fromDateInput.value = selectedHolidayDate; // Set From Date to the holiday date
                toDateInput.value = selectedHolidayDate;   // Set To Date to the holiday date

                // Set min and max for both date inputs
                fromDateInput.min = selectedHolidayDate;
                fromDateInput.max = selectedHolidayDate;
                toDateInput.min = selectedHolidayDate;
                toDateInput.max = selectedHolidayDate;
            });




            monthDropdown.addEventListener('change', function () {
                const selectedMonth = this.value;
                if (selectedMonth !== "select") {
                    fetchAttendanceData(selectedMonth, currentYear);
                }
            });
            document.addEventListener('click', function (event) {
                if (event.target.closest('.open-modal')) {
                    event.preventDefault();

                    const link = event.target.closest('.open-modal');
                    const employeeId = link.getAttribute('data-employee-id');
                    const date = link.getAttribute('data-date');
                    const innTime = link.getAttribute('data-inn');
                    const outTime = link.getAttribute('data-out');
                    const II = link.getAttribute('data-II');
                    const OO = link.getAttribute('data-OO');
                    const atct = link.getAttribute('data-atct');
                    const dataexist = link.getAttribute('data-exist');
                    const status = link.getAttribute('data-status');
                    const draft = link.getAttribute('data-draft');

                    const requestData = JSON.parse(link.getAttribute('data-request-data')); // This parses the JSON string into an object

                    // Log the parsed data (just for debugging)
                    console.log(status);

                    // Check if the status is approved, and populate fields accordingly
                    if (status === '1') { // Approved status
                        // Show the groups first
                        document.getElementById('OtherRemarkDataGroup').style.display = 'block';
                        document.getElementById('OtherReasonDataGroup').style.display = 'block';
                        document.getElementById('reportingRemarkGroup').style.display = 'block';

                        // Use setTimeout to ensure elements are shown before setting values
                        setTimeout(function () {
                            // Populate the fields with actual values from requestData
                            document.getElementById('OtherRemarkData').value = requestData.Remark || ''; // Remark for in time
                            document.getElementById('OtherReasonData').value = requestData.Reason || ''; // Reason for out time
                            document.getElementById('reportingRemark').value = requestData.R_Remark || ''; // Reporting remark from request data
                        }, 0);
                    }


                    if (status === '0') { // Approved status
                        // Show the groups first
                        document.getElementById('OtherRemarkDataGroup').style.display = 'block';
                        document.getElementById('OtherReasonDataGroup').style.display = 'block';
                        document.getElementById('reportingRemarkGroup').style.display = 'block';

                        // Use setTimeout to ensure elements are shown before setting values
                        setTimeout(function () {
                            // Populate the fields with actual values from requestData
                            document.getElementById('OtherRemarkData').value = requestData.Remark || ''; // Remark for in time
                            document.getElementById('OtherReasonData').value = requestData.Reason || ''; // Reason for out time
                            document.getElementById('reportingRemark').value = requestData.R_Remark || ''; // Reporting remark from request data
                        }, 0);
                    }


                    // Initialize content for request-date
                    let requestDateContent = `
            <div style="text-align: left;">
                <b>Request Date: ${date}</b>
                <span style="color: ${draft === '3' || draft === null ? 'red' : (status === '1' ? 'green' : 'red')}; float: right;">
                    <b style="color: black; font-weight: bold;">Status:</b> 
                    ${draft === '3' || draft === null ? 'Draft' : (status === '1' ? 'Approved' : 'Reject')}
                </span>
            </div>
        `;

                    // Check conditions for In
                    const lateClass = (innTime > II) ? 'text-danger' : '';
                    const earlyClass = (outTime < OO) ? 'text-danger' : '';

                    if (innTime > II) {
                        requestDateContent += `In: <span class="${lateClass}">${innTime} Late</span><br>`;
                    } else if (innTime <= II) {
                        requestDateContent += `In: <span>${innTime} On Time</span><br>`;
                    }

                    // Check conditions for Out
                    if (outTime < OO) {
                        requestDateContent += `Out: <span class="${earlyClass}">${outTime} Early</span>`;
                    } else if (outTime >= OO) {
                        requestDateContent += `Out: <span>${outTime} On Time</span>`;
                    }

                    // Set innerHTML only if there is content to display
                    document.getElementById('request-date').innerHTML = requestDateContent;

                    document.getElementById('employeeid').value = employeeId;
                    document.getElementById('Atct').value = atct;
                    document.getElementById('requestDate').value = date;

                    // Clear previous values and hide all groups
                    document.getElementById('remarkIn').value = '';
                    document.getElementById('remarkOut').value = '';

                    // Hide reason and remark groups for In and Out initially
                    document.getElementById('reasonInGroup').style.display = 'none';
                    document.getElementById('remarkInGroup').style.display = 'none';
                    document.getElementById('reasonOutGroup').style.display = 'none';
                    document.getElementById('remarkOutGroup').style.display = 'none';

                    // Fetch company_id and department_id based on employeeId
                    fetch(`/api/getEmployeeDetails/${employeeId}`)
                        .then(response => response.json())
                        .then(data => {
                            const companyId = data.company_id;
                            const departmentId = data.department_id;

                            // Fetch reasons based on companyId and departmentId
                            return fetch(`/api/getReasons/${companyId}/${departmentId}`);
                        })
                        .then(response => response.json())
                        .then(reasons => {
                            // Populate the reason dropdowns
                            reasons.forEach(reason => {
                                const optionIn = document.createElement('option');
                                optionIn.value = reason.ReasonId;
                                optionIn.textContent = reason.reason_name;
                                document.getElementById('reasonInDropdown').appendChild(optionIn);

                                const optionOut = document.createElement('option');
                                optionOut.value = reason.ReasonId;
                                optionOut.textContent = reason.reason_name;
                                document.getElementById('reasonOutDropdown').appendChild(optionOut);

                                const optionOther = document.createElement('option');
                                optionOther.value = reason.ReasonId;
                                optionOther.textContent = reason.reason_name;
                                document.getElementById('otherReasonDropdown').appendChild(optionOther);
                            });
                        })
                        .catch(error => console.error('Error fetching reasons:', error));

                    const modal = new bootstrap.Modal(document.getElementById('AttendenceAuthorisation'));
                    modal.show();
                }
            });

            // document.addEventListener('click', function (event) {
            //     if (event.target.closest('.open-modal')) {
            //         event.preventDefault();

            //         const link = event.target.closest('.open-modal');
            //         const employeeId = link.getAttribute('data-employee-id');
            //         const date = link.getAttribute('data-date');
            //         const innTime = link.getAttribute('data-inn');
            //         const outTime = link.getAttribute('data-out');
            //         const II = link.getAttribute('data-II');
            //         const OO = link.getAttribute('data-OO');
            //         const atct = link.getAttribute('data-atct');
            //         const dataexist = link.getAttribute('data-exist');
            //         const status = link.getAttribute('data-status');
            //         const draft = link.getAttribute('data-draft');
            //         // Determine classes based on conditions
            //         const lateClass = (innTime > II) ? 'text-danger' : '';
            //         const earlyClass = (outTime < OO) ? 'text-danger' : '';
            //         // Initialize content for request-date
            //         if (dataexist === 'true') {
            //             // Select the modal footer and hide it
            //             const modalFooter = document.getElementById('modal-footer');
            //             console.log(modalFooter)
            //             if (modalFooter) {
            //                 modalFooter.style.display = 'none';
            //             }
            //         }
            //         // Initialize content for request-date
            //         let requestDateContent = `
            //                 <div style="text-align: left;">
            //                     <b>Request Date: ${date}</b>
            //                     <span style="color: ${draft === '3' || draft === null ? 'red' : (status === '1' ? 'green' : 'red')}; float: right;">
            //                         <b style="color: black; font-weight: bold;">Status:</b> 
            //                         ${draft === '3' || draft === null ? 'Draft' : (status === '1' ? 'Approved' : 'Reject')}
            //                     </span>
            //                 </div>
            //             `;
            //         // Check conditions for In
            //         if (innTime > II) {
            //             requestDateContent += `In: <span class="${lateClass}">${innTime} Late</span><br>`;
            //         } else if (innTime <= II) {
            //             requestDateContent += `In: <span>${innTime}On Time</span><br>`; // Optional: show "On Time" if needed
            //         }

            //         // Check conditions for Out
            //         if (outTime < OO) {
            //             requestDateContent += `Out: <span class="${earlyClass}">${outTime} Early</span>`;
            //         } else if (outTime >= OO) {
            //             requestDateContent += `Out: <span>${outTime}On Time</span>`; // Optional: show "On Time" if needed
            //         }

            //         // Set innerHTML only if there is content to display
            //         document.getElementById('request-date').innerHTML = requestDateContent;

            //         document.getElementById('employeeid').value = employeeId;
            //         document.getElementById('Atct').value = atct;
            //         document.getElementById('requestDate').value = date;

            //         // Clear previous values and hide all groups
            //         document.getElementById('remarkIn').value = '';
            //         document.getElementById('remarkOut').value = '';
            //         // document.getElementById('reasonInDropdown').innerHTML = '';
            //         // document.getElementById('reasonOutDropdown').innerHTML = '';

            //         document.getElementById('reasonInGroup').style.display = 'none';
            //         document.getElementById('remarkInGroup').style.display = 'none';
            //         document.getElementById('reasonOutGroup').style.display = 'none';
            //         document.getElementById('remarkOutGroup').style.display = 'none';

            //         // Fetch company_id and department_id based on employeeId
            //         fetch(`/api/getEmployeeDetails/${employeeId}`)
            //             .then(response => response.json())
            //             .then(data => {
            //                 console.log(data);
            //                 const companyId = data.company_id;
            //                 const departmentId = data.department_id;

            //                 // Fetch reasons based on companyId and departmentId
            //                 return fetch(`/api/getReasons/${companyId}/${departmentId}`);
            //             })
            //             .then(response => response.json())
            //             .then(reasons => {
            //                 // Populate the reason dropdowns
            //                 reasons.forEach(reason => {
            //                     const optionIn = document.createElement('option');
            //                     optionIn.value = reason.ReasonId;
            //                     optionIn.textContent = reason.reason_name;
            //                     document.getElementById('reasonInDropdown').appendChild(optionIn);

            //                     const optionOut = document.createElement('option');
            //                     optionOut.value = reason.ReasonId;
            //                     optionOut.textContent = reason.reason_name;
            //                     document.getElementById('reasonOutDropdown').appendChild(optionOut);

            //                     const optionOther = document.createElement('option');
            //                     optionOther.value = reason.ReasonId;
            //                     optionOther.textContent = reason.reason_name;
            //                     document.getElementById('otherReasonDropdown').appendChild(optionOther);
            //                 });
            //             })
            //             .catch(error => console.error('Error fetching reasons:', error));

            //         let inConditionMet = false;
            //         let outConditionMet = false;
            //         if (innTime === outTime) {
            //             remarkInGroup.style.display = 'none';
            //             reasonInGroup.style.display = 'none';
            //             remarkOutGroup.style.display = 'none';
            //             reasonOutGroup.style.display = 'none';
            //             document.getElementById('otherReasonGroup').style.display = 'block'; // Show Other Reason dropdown
            //             document.getElementById('otherRemarkGroup').style.display = 'block'; // Show Other Remark input

            //         }
            //         else {
            //             // Your existing time condition logic...
            //             if (innTime > II) {
            //                 remarkInGroup.style.display = 'block';
            //                 reasonInGroup.style.display = 'block';
            //                 // document.getElementById('remarkIn').value = 'Your remark for late in';
            //                 inConditionMet = true;
            //             }
            //             if (outTime == '00:00') {
            //                 remarkOutGroup.style.display = 'block';
            //                 reasonOutGroup.style.display = 'block';
            //                 // document.getElementById('remarkOut').value = 'Your remark for early out';
            //                 document.getElementById('otherReasonGroup').style.display = 'none'; // Show Other Reason dropdown
            //                 document.getElementById('otherRemarkGroup').style.display = 'none'; // Show Other Remark input

            //             }

            //             if (outTime < OO) {
            //                 remarkOutGroup.style.display = 'block';
            //                 reasonOutGroup.style.display = 'block';
            //                 // document.getElementById('remarkOut').value = 'Your remark for early out';
            //                 outConditionMet = true;
            //             }

            //             // If both conditions are met, display both groups
            //             if (inConditionMet && outConditionMet) {
            //                 remarkInGroup.style.display = 'block';
            //                 reasonInGroup.style.display = 'block';
            //                 remarkOutGroup.style.display = 'block';
            //                 reasonOutGroup.style.display = 'block';
            //                 document.getElementById('otherReasonGroup').style.display = 'none'; // Show Other Reason dropdown
            //                 document.getElementById('otherRemarkGroup').style.display = 'none'; // Show Other Remark input

            //             }
            //         }
            //         const modal = new bootstrap.Modal(document.getElementById('AttendenceAuthorisation'));
            //         modal.show();
            //     }
            // });



            document.getElementById('reasonInDropdown').addEventListener('change', function () {
                const selectedIn = this.value;
                const selectedOut = document.getElementById('reasonOutDropdown').value;

                // If an "In" reason is selected, check if an "Out" reason is selected
                if (selectedIn && selectedOut) {
                    // You could choose to prevent changing or notify the user here if needed
                    console.log('Both reasons are selected, no changes made.');
                }
            });

            document.getElementById('reasonOutDropdown').addEventListener('change', function () {
                const selectedOut = this.value;
                const selectedIn = document.getElementById('reasonInDropdown').value;

                // If an "Out" reason is selected, check if an "In" reason is selected
                if (selectedIn && selectedOut) {
                    // You could choose to prevent changing or notify the user here if needed
                    console.log('Both reasons are selected, no changes made.');
                }
            });

            document.getElementById('sendButton').addEventListener('click', function () {
                const form = document.getElementById('attendanceForm');

                // Use Fetch API to submit the form
                fetch(form.action, {
                    method: 'POST',
                    body: new FormData(form),
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    }
                })
                    .then(response => response.json())
                    .then(data => {
                        const responseMessage = document.getElementById('responseMessage');
                        if (data.success) {
                            responseMessage.innerText = data.message;
                            responseMessage.style.display = 'block'; // Show the message
                            $('#AttendenceAuthorisation').modal('hide'); // Optionally hide the modal
                        } else {
                            responseMessage.innerText = data.message;
                            responseMessage.classList.remove('text-success');
                            responseMessage.classList.add('text-danger');
                            responseMessage.style.display = 'block'; // Show the message
                        }
                    })

                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while submitting the request.');
                    });
            });

            function fetchAttendanceData(selectedMonth, year) {
                const monthNumber = monthNames.indexOf(selectedMonth) + 1;
                const employeeId = {{ Auth::user()->EmployeeID }};

                cardHeaders.forEach(header => {
                    header.textContent = `${selectedMonth} ${year}`;
                });
                if (list_of_attendance_req_card) {
                    list_of_attendance_req_card.textContent = `Attendance Request List ${selectedMonth} ${year}`;
                }

                fetch(`/attendance/${year}/${monthNumber}/${employeeId}`)
                    .then(response => response.json())
                    .then(data => {
                        const calendar = document.querySelector('.calendar tbody');
                        calendar.innerHTML = '';

                        const daysInMonth = new Date(year, monthNumber, 0).getDate();
                        const firstDayOfMonth = new Date(year, monthNumber - 1, 1).getDay();

                        let currentRow = document.createElement('tr');
                        let latenessCount = 0;


                        // Get the lateness container
                        const latenessContainer = document.querySelector('.late-atnd');
                        latenessContainer.innerHTML = ''; // Clear previous lateness data

                        // Fill empty cells for the first week
                        for (let i = 0; i < firstDayOfMonth; i++) {
                            const emptyCell = document.createElement('td');
                            emptyCell.classList.add('day');
                            currentRow.appendChild(emptyCell);
                        }

                        for (let day = 1; day <= daysInMonth; day++) {
                            const dayData = data.find(record => {
                                const recordDate = new Date(record.AttDate);
                                return recordDate.getDate() === day && recordDate.getMonth() + 1 === monthNumber;
                            });

                            const cell = document.createElement('td');
                            cell.classList.add('day');
                            const today = new Date();
                            today.setHours(0, 0, 0, 0); // Set time to midnight for accurate comparison
                            // Determine if the day is a Sunday
                            const currentDate = new Date(year, monthNumber - 1, day);
                            if (currentDate.getDay() === 0) { // 0 is Sunday
                                cell.style.backgroundColor = 'rgb(209,243,174)';
                                cell.innerHTML = `<div class="day-num">${day}</div>`; // Just show the day number
                            }
                            else {
                                if (dayData) {
                                    const attValue = dayData.AttValue;
                                    const innTime = dayData.Inn;
                                    const iiTime = dayData.II;
                                    console.log(dayData);

                                    let Atct = 0; // Initialize Atct
                                    if (dayData.InnLate == 1 && dayData.OuttLate == 0) {
                                        Atct = 1;
                                    } else if (dayData.InnLate == 0 && dayData.OuttLate == 1) {
                                        Atct = 2;
                                    } else if (dayData.InnLate == 1 && dayData.OuttLate == 1) {
                                        Atct = 12;
                                    } else if ((dayData.InnLate == 0 || dayData.InnLate === '') && (dayData.OuttLate == 0 || dayData['OuttLate'] === '')) {
                                        Atct = 3;
                                    }
                                    let latenessStatus = '';
                                    if (innTime > iiTime || dayData.Outt < dayData.OO) {
                                        latenessCount++;
                                        latenessStatus = `L${latenessCount}`;

                                        // Determine if we need to add the "danger" class
                                        const punchInDanger = innTime > iiTime ? 'danger' : '';
                                        const punchOutDanger = dayData.OO > dayData.Outt ? 'danger' : '';
                                        // Determine the status label and set up the modal link if needed
                                        let statusLabel = '';
                                        let modalLink = '';

                                        if (dayData.Status === 0) {
                                            statusLabel = 'Request';
                                            modalLink = `
                                                    <a href="#" class="open-modal" 
                                                    data-date="${day}-${monthNames[monthNumber - 1]}-${year}" 
                                                    data-inn="${innTime}" 
                                                    data-out="${dayData.Outt}" 
                                                    data-ii="${dayData.II}" 
                                                    data-oo="${dayData.OO}" 
                                                    data-atct="${Atct}" 
                                                    data-status="${dayData.Status}" 
                                                    data-employee-id="${employeeId}">
                                                        ${statusLabel}
                                                    </a>`;
                                        }

                                        else if (dayData.Status === 1) {
                                            statusLabel = 'Approved';
                                        }
                                        latenessContainer.innerHTML += `
                                        <div class="late-atnd">
                                            <div>
                                                <span class="late-l1">${latenessStatus}</span>
                                                <h6 class="float-start mt-2">${day} ${monthNames[monthNumber - 1]} ${year}</h6>
                                                <div class="float-end mt-1">
                                                    <label style="padding:6px 13px;font-size: 11px;" class="mb-0 sm-btn btn-outline success-outline" title="${statusLabel}">
                                                        ${dayData.Status === 0 ? modalLink : statusLabel}
                                                    </label>
                                                </div>
                                            </div>
                                            <div style="color:#777171; float: left; width: 100%; margin-top:5px;">
                                                <span class="float-start">Punch in <span class="${punchInDanger}"><b>${innTime}</b></span></span>
                                                <span class="float-end">Punch Out <span class="${punchOutDanger}"><b>${dayData.Outt || '00:00'}</b></span></span>
                                            </div>
                                        </div>
                                        `;
                                    }

                                    // Icon logic
                                    let iconHtml = '';
                                    const today = new Date();
                                    const isCurrentMonth = monthNumber === today.getMonth() + 1;
                                    const isLastMonth = monthNumber === today.getMonth(); // Check if it's the last month
                                    if (!(isCurrentMonth && (day > daysInMonth - 2)) && !isLastMonth) { // Last two days of current month or last month
                                        if (dayData.Inn > dayData.II || dayData.Outt < dayData.OO || dayData.Inn === dayData.Outt) {
                                            iconHtml = `<i class="fas fa-plus-circle primary calender-icon"></i>`;
                                        }
                                    }

                                    // Append iconHtml to your cell if needed
                                    if (iconHtml) {
                                        cell.innerHTML += iconHtml;
                                    }
                                    let attenBoxContent = '';
                                    if (latenessStatus && dayData.Status === 0) {
                                        attenBoxContent += `<span class="atte-late">${latenessStatus}</span>`; // Add lateness status to the calendar cell
                                    }

                                    if (latenessStatus && dayData.Status === 1) {
                                        // If status is 1 and latenessStatus already shown, do not add it again
                                        if (!attenBoxContent.includes(latenessStatus)) {
                                            attenBoxContent += `<span class="atte-late-status">${latenessStatus}</span>`; // Add lateness status to the calendar cell
                                        }
                                    }

                                    switch (attValue) {
                                        case 'P':
                                            attenBoxContent += `<span class="atte-present">P</span>`;
                                            //     attenBoxContent += `
                                            //     <a href="#" class="open-modal" data-date="${day}-${monthNames[monthNumber - 1]}-${year}" data-inn="${innTime}" data-out="${dayData.Outt}" data-ii="${dayData.II}" data-oo="${dayData.OO}" data-atct="${Atct}" 
                                            //     data-employee-id="${employeeId}" data-exist="${dayData.DataExist}"data-status="${dayData.Status}" data-draft="${dayData.DraftStatus}">
                                            //          ${iconHtml}
                                            //     </a>
                                            // `;
                                            break;
                                        case 'A':
                                            attenBoxContent += `<span class="atte-absent">A</span>`;
                                            break;
                                        case 'HO':
                                            attenBoxContent += `<span class="holiday-cal">${attValue}</span>`;
                                            break;
                                        case 'OD':
                                            attenBoxContent += `<span class="atte-OD">${attValue}</span>`;
                                            attenBoxContent += `
                                            <a href="#" class="open-modal" data-date="${day}-${monthNames[monthNumber - 1]}-${year}" data-inn="${innTime}" data-out="${dayData.Outt}" data-ii="${dayData.II}" data-oo="${dayData.OO}" data-atct="${Atct}" 
                                            data-employee-id="${employeeId}" data-exist="${dayData.DataExist}"data-status="${dayData.Status}" data-draft="${dayData.DraftStatus}" data-request-data='${JSON.stringify(dayData.RequestDetails)}'>
                                                 ${iconHtml}
                                            </a> `;
                                            break;
                                        case 'PH':
                                        case 'CH':
                                        case 'SH':
                                        case 'PL':
                                        case 'FL':
                                        case 'SL':
                                        case 'CL':
                                            attenBoxContent += `<span class="atte-all-leave">${attValue}</span>`;
                                            attenBoxContent += `
                                            <a href="#" class="open-modal" data-date="${day}-${monthNames[monthNumber - 1]}-${year}" data-inn="${innTime}" data-out="${dayData.Outt}" data-ii="${dayData.II}" data-oo="${dayData.OO}" data-atct="${Atct}" 
                                            data-employee-id="${employeeId}" data-exist="${dayData.DataExist}"data-status="${dayData.Status}" data-draft="${dayData.DraftStatus}" data-request-data='${JSON.stringify(dayData.RequestDetails)}'>
                                                 ${iconHtml}
                                            </a> `;
                                            break;
                                        default:
                                            attenBoxContent += `
                                            <span class="atte-present"></span>
                                            <a href="#" class="open-modal" data-date="${day}-${monthNames[monthNumber - 1]}-${year}" data-inn="${innTime}" data-out="${dayData.Outt}" data-ii="${dayData.II}" data-oo="${dayData.OO}" data-atct="${Atct}" data-employee-id="${employeeId}">
                                                 ${iconHtml}
                                            </a>
                                        `;
                                            break;
                                    }


                                    const punchInDanger = dayData.Inn > dayData.II ? 'danger' : '';
                                    const punchOutDanger = dayData.OO > dayData.Outt ? 'danger' : '';

                                    cell.innerHTML = `
                                        <div class="day-num">${day}</div>
                                        <div class="punch-section">
                                            <span class="${punchInDanger}"><b>In:</b> ${innTime || '00:00'}</span><br>
                                            <span class="${punchOutDanger}"><b>Out:</b> ${dayData.Outt || '00:00'}</span>
                                        </div>
                                        <div class="atten-box">${attenBoxContent}</div>
                                    `;
                                }
                                else {
                                    const today = new Date();
                                    today.setHours(0, 0, 0, 0); // Set time to midnight for accurate comparison

                                    let iconHtml = '';
                                    const isCurrentMonth = monthNumber === today.getMonth() + 1;
                                    const isLastMonth = monthNumber === today.getMonth(); // Check if it's the last month

                                    if (!(isCurrentMonth && (day > daysInMonth - 2)) && !isLastMonth) { // Last two days of current month or last month
                                        iconHtml = `<i class="fas fa-plus-circle primary calender-icon"></i>`;


                                    }
                                    cell.innerHTML = `
                                    <div class="day-num">${day}</div>
                                    <div class="atten-box">
                                        <a href="#" class="open-modal" data-date="${day}-${monthNames[monthNumber - 1]}-${year}" data-inn="00:00" data-out="00:00" data-ii="00:00" data-oo="00:00" data-atct="3" data-employee-id="${employeeId}">
                                                 ${iconHtml}
                                        </a></div>`;

                                }
                            }

                            currentRow.appendChild(cell);

                            if ((firstDayOfMonth + day) % 7 === 0) {
                                calendar.appendChild(currentRow);
                                currentRow = document.createElement('tr');
                            }
                        }

                        if (currentRow.childElementCount > 0) {
                            calendar.appendChild(currentRow);
                        }
                    })
                    .catch(error => console.error('Error fetching attendance data:', error));
            }

        });

        $(document).ready(function () {
            $('#leaveForm').on('submit', function (e) {
                e.preventDefault(); // Prevent the default form submission
                const url = $(this).attr('action'); // Form action URL
                const employeeId = {{ Auth::user()->EmployeeID }};
                $.ajax({
                    url: url, // Form action URL
                    type: 'POST',
                    data: $(this).serialize(),
                    success: function (response) {
                        $('#leaveMessage').show(); // Show the message div
                        if (response.success) {
                            $('#leaveMessage').removeClass('alert-danger').addClass('alert-success')
                                .text('Form submitted successfully!').show();
                            // Fetch the updated leave list
                            fetchLeaveList(employeeId);
                        } else {
                            $('#leaveMessage').removeClass('alert-success').addClass('alert-danger')
                                .text(response.message).show();
                        }
                    },
                    error: function (xhr, status, error) {
                        $('#leaveMessage').removeClass('alert-success').addClass('alert-danger')
                            .text('An error occurred: ' + error).show();
                    }
                });
            });

            function fetchLeaveList(employeeId) {
                $.ajax({
                    url: '{{ route('fetchLeaveList') }}', // Update with your actual route
                    type: 'GET',
                    data: { employee_id: employeeId }, // Pass employee ID
                    success: function (data) {
                        // Assuming 'data' contains the HTML for the leave list
                        $('tbody').html(data.html);
                    },
                    error: function (xhr, status, error) {
                        alert('Could not fetch leave list: ' + error);
                    }
                });
            }
        });
        $(document).ready(function () {
            $('#AttendenceAuthorisation').on('hidden.bs.modal', function () {
                location.reload(); // Reloads the page when the modal is closed
            });
        });

    </script>